from selenium import webdriver
import json
import requests

driver = webdriver.Chrome()
driver.get("http://47.103.35.164:5007/user/login")
driver.maximize_window()
driver.find_element_by_id("loginName").send_keys("huqian")
driver.find_element_by_id('passWord').send_keys("123456")
driver.find_element_by_xpath('//button').click()
token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyTmFtZSI6Imh1cWlhbiIsImV4cCI6MTYxMDY4OTkzOSwiaWF0IjoxNTc0NDAxOTM5fQ.mqyUrjccO68JL6xKx2rVRFbdeNwnhkJen7NC7tL0XuE"
driver.add_cookie(token)
driver.refresh()
driver.find_element_by_id("//*[@class='anticon']").click()

cookies = {
    'Accept': 'application/json',
    'communityId': '201901',
    'Connection': 'keep-alive',
    "Content-Type": 'application/json',
    'Host': '47.103.35.164:5007',
    'loginName': 'huqian',
    'Origin': 'http://47.103.35.164:5007',
    'osType': 1,
    'Referer': 'http://47.103.35.164:5007/payment/management',
    'userId': 10014,
    'x-auth-token': 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyTmFtZSI6Imh1cWlhbiIsImV4cCI6MTYxMDY4OTkzOSwiaWF0IjoxNTc0NDAxOTM5fQ.mqyUrjccO68JL6xKx2rVRFbdeNwnhkJen7NC7tL0XuE'
}


cookie =json.loads(cookie)
for c in cookie:
    driver.add_cookie(c)
# # 刷新页面
driver.refresh()

headers = {
    "userID": '10014',
    "loginName": 'huqian',
    "communityId": "201901",
    "Content-Type": "application/json",
    'x-auth-token': ' eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyTmFtZSI6Imh1cWlhbiIsImV4cCI6MTYxMDY4OTkzOSwiaWF0IjoxNTc0NDAxOTM5fQ.mqyUrjccO68JL6xKx2rVRFbdeNwnhkJen7NC7tL0XuE'
}
response = requests.get(url='http://47.103.35.164:5007/integratedKanban', headers=headers, cookies=cookies)
print(response.text)
