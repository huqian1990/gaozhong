import unittest
import logging
from config import *
from lib.htmlrunner import HTMLTestRunner
from lib.send_mail import send_email
import os

suite = unittest.defaultTestLoader.discover(test_path)
logging.info("{}测试开始{}".format("=" * 25, "=" * 25))
with open(REPORT_FILE, "wb")as f:
    HTMLTestRunner(stream=f,
                   title=REPORT_FILE,
                   description=REPORT_DESCRIPTION).run(suite)
    logging.debug("{}测试结束{}".format("=" * 25, "=" * 25))
