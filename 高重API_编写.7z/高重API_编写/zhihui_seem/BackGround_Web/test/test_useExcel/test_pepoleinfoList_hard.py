from lib.basecase import  BaseCase
class TestUserList(BaseCase):   # 这里直接继承BaseCase
    def test_peoplelist_normal(self):
        case_data = self.get_case_data("正确查询社区居民列表")
        self.send_request(case_data)

    def test_peoplelist_wrong(self):
        case_data = self.get_case_data("错误查询_无data")
        self.send_request(case_data)

