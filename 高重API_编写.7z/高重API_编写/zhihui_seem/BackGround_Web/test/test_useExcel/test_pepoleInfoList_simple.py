import xlrd
import unittest
import requests
from lib.read_excel import *
from lib.case_log import *
import logging


class TestPepple(unittest.TestCase):
    @classmethod
    def setUpClass(cls):  # 整个测试类只执行一次
        cls.data_list = excel_to_list("E:\高重API_编写\zhihui_seem\BackGround_Web\data\社区居民档案_居民信息.xls",
                                      "查询居民信息列表")  # 读取该测试类所有用例数据
        # cls.data_list 同 self.data_list 都是该类的公共属性

###下面方法是直接手动修改
    def test_peopleInfo_list(self):
        case_data = get_test_data(self.data_list, '正确查询社区居民列表')  # 从数据列表中查找到该用例数据
        if not case_data:  # 有可能为None
            logging.error("用例数据不存在")
        url =case_data.get('URL')   # 从字典中取数据，excel中的标题也必须是小写url
        data = case_data.get('data')  # 注意字符串格式，需要用json.loads()转化为字典格式
        headers=eval(case_data.get('headers')) ##获取请求头
        res = requests.post(url=url, headers=headers, data=data)# 表单请求，数据转为字典格式
        res_dict = res.json()
        log_case_info('正确查询社区居民列表', url, data, "200", res_dict)
        ##断言这里有点复杂，简单Code即可
        self.assertEqual('200', res_dict['code'])


###这个方法是把url,data,header,res_dict封装成了一个方法——————在case_log中，但觉上面的方便点
    def test_peopleInfo_list_unnormal(self):
        case_data = get_test_data(self.data_list, '错误查询社区居民列表')  # 从数据列表中查找到该用例数据
        if not case_data:  # 有可能为None
            logging.error("用例数据不存在")
######case_log中写了一个方法：get_excel_info，把url ，data,res等等信息封装成方法
        info = get_excel_info(case_data)
        url = info[0]
        data = info[1]
        print(data)
        res_dict = info[3]
        log_case_info('错误查询社区居民列表', url, data, "500", res_dict)
        ##断言这里有点复杂，简单Code即可
        self.assertEqual('500', res_dict['code'])


if __name__ == '__main__':  # 非必要，用于测试我们的代码
    unittest.main(verbosity=2)
