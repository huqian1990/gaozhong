####这里存放所有请求的方法
import unittest
import sys
sys.path.append("..//..")   ##把系统路径提升到主目录下
from lib.case_log import *

class BaseCase(unittest.TestCase):   # 继承unittest.TestCase
    @classmethod
    def get_data_list(cls,data_file):
        if cls.__name__ != 'BaseCase':
            cls.data_list = excel_to_list(data_file, cls.__name__)

    def get_case_data(self, case_name):
        return get_test_data(self.data_list, case_name)

    def send_request_info(self,case_data):
        case_name = case_data.get('case_name')
        url = case_data.get('URL')  # 获得URL地址
        data = case_data.get('data')  # 注意字符串格式，需要用json.loads()转化为字典格式
        headers = eval(case_data.get('headers'))  ##获取请求头
        method = case_data.get('method')  ##获得请求的方法：post/get
        expect_res = case_data.get('expect_res')  ###获得期望结果（部分期望结果太长而且会变化，看情况决定）

        if method == "GET":
            requests.get(url=url, headers=headers, params=json.loads(data))
        else:
            res = requests.post(url=url, data=json.loads(data), headers=json.loads(headers))  ###注意data这边的传参写法
            log_case_info(case_name, url, data, json.dumps(json.loads(expect_res), sort_keys=True),
                          json.dumps(res.json(), ensure_ascii=False, sort_keys=True))
            self.assertDictEqual(res.json(), json.loads(expect_res))
