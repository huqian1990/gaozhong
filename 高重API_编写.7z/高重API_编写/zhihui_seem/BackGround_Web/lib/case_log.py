from  config import *
import logging
import json
from lib.read_excel import *
import requests
def log_case_info(case_name, url, data, expect_res, res_text):
    if isinstance(data,dict):
        data = json.dumps(data, ensure_ascii=False)  # 如果data是字典格式，转化为字符串
    logging.info("测试用例：{}".format(case_name))
    logging.info("url：{}".format(url))
    logging.info("请求参数：{}".format(data))
    logging.info("期望结果：{}".format(expect_res))
    logging.info("实际结果：{}".format(res_text))



def get_excel_info(case_data):
    url = case_data.get('URL')  # 从字典中取数据，excel中的标题也必须是小写url
    data = case_data.get('data')  # 注意字符串格式，需要用json.loads()转化为字典格式
    headers = eval(case_data.get('headers'))  ##获取请求头
    res = requests.post(url=url, headers=headers, data=data)  # 表单请求，数据转为字典格式
    res_dict = res.json()
    return url,data,headers,res_dict





