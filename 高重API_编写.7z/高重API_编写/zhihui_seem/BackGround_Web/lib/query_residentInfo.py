from lib.db_conn import get_conn, query_db, del_db
import random

def query_companyId(company_name):
    conn = get_conn()
    companyId = query_db(conn, "SELECT company_id FROM company_info WHERE company_name='{}' and del_flag='0'".format(company_name))
    if companyId:
        return (companyId[0][0])
    else:
        company_names = query_db(conn, "SELECT company_name FROM company_info WHERE  del_flag='0'")
        company_name1 = random.choice(company_names)
        companyId = query_db(conn,"SELECT company_id FROM company_info WHERE company_name='{}' and del_flag='0'".format( company_name1[0]))
        return (companyId[0][0],company_name1[0])


if __name__=="__main__":
    query_companyId( )




