import smtplib  # 用于建立smtp连接
from email.mime.text import MIMEText  # 邮件需要专门的MIME格式

# 1. 编写邮件内容（Email邮件需要专门的MIME格式）
msg = MIMEText('this is a test email', 'plain', 'utf-8')  # plain指普通文本格式邮件内容

# 2. 组装Email头（发件人，收件人，主题）
msg['From'] = 'test_results@sina.com'  # 发件人
msg['To'] = '1015948931@qq.com'  # 收件人
msg['Subject'] = 'Api Test Report'  # 邮件主题

# 3. 连接smtp服务器并发送邮件
smtp = smtplib.SMTP_SSL('smtp.sina.com')  # smtp服务器地址 使用SSL模式
smtp.login('vaexiaoqianzi@sina.com', 'huqian19901017')  # 用户名和密码
smtp.sendmail("1015948931@qq.com", msg.as_string())
smtp.quit()