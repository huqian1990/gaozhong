from selenium import webdriver
from time import  sleep
import random
##########打开CMDB界面并最大化#########
driver=webdriver.Chrome()
driver.get('http://47.103.37.193:8083/#/itrs/manage/tools?k=aa2ae29ddb164b86aa79409666592146')
driver.maximize_window()
driver.find_element_by_id("userName").send_keys("huqian")
driver.find_element_by_id("password").send_keys("123456")
driver.find_element_by_xpath("//*[@type='button']").click()
sleep(2)
driver.find_element_by_xpath("//*[@class='go-btn']").click()
#####点击工具库管理按钮
driver.find_element_by_xpath("//*[@class='ant-layout-sider-children']/ul/li[14]").click()
sleep(1)

driver.find_element_by_xpath("//*[@class='ant-input']").send_keys("完整TOOL_不给改")


