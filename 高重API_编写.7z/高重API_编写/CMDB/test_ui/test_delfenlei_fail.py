from selenium import webdriver
from time import  sleep

##########打开CMDB界面并最大化#########
driver=webdriver.Chrome()
driver.get('http://47.103.37.193:8083/#/itrs/manage/tools?k=aa2ae29ddb164b86aa79409666592146')
driver.maximize_window()

##########输入用户名/密码登录#########
driver.find_element_by_id("userName").send_keys("huqian")
driver.find_element_by_id("password").send_keys("123456")
driver.find_element_by_xpath("//*[@type='button']").click()
sleep(2)


##########工具库管理#########
#####进入CMDB界面
driver.find_element_by_xpath("//*[@class='go-btn']").click()
sleep(2)
#####点击工具库管理按钮
driver.find_element_by_xpath("//*[@class='ant-layout-sider-children']/ul/li[14]").click()
sleep(1)

####test点击第3个分类
driver.find_element_by_xpath("//*[@class='antd-pro-pages-i-t-r-s-tools-menuBigBox']/div/div/div/div/ul/li[3]").click()
sleep(2)
# driver.find_element_by_xpath("//*[@class='anticon anticon-delete icon']").click()


driver.find_element_by_xpath("//*[@class='antd-pro-pages-i-t-r-s-tools-menuBigBox']/div/div/div/div/ul/li[3]/span[2]/span/div/span[2]/i[1]").click()