from selenium import webdriver
from time import  sleep
from lib.ui_get_fenlei import get_fenleiInfo

##########打开CMDB界面并最大化#########
driver=webdriver.Chrome()
driver.get('http://47.103.37.193:8083/#/itrs/manage/tools?k=aa2ae29ddb164b86aa79409666592146')
driver.maximize_window()

##########输入用户名/密码登录#########
driver.find_element_by_id("userName").send_keys("huqian")
driver.find_element_by_id("password").send_keys("123456")
driver.find_element_by_xpath("//*[@type='button']").click()
sleep(2)


##########工具库管理#########
#####进入CMDB界面
driver.find_element_by_xpath("//*[@class='go-btn']").click()
sleep(2)
#####点击工具库管理按钮
driver.find_element_by_xpath("//*[@class='ant-layout-sider-children']/ul/li[14]").click()


#######遍历分类列表，输出已存在的分类
'''
fenlei=[]
ul = driver.find_element_by_xpath("//*[@class='antd-pro-pages-i-t-r-s-tools-menuBigBox']/div/div/div/div/ul")
lis = ul.find_elements_by_xpath('li')
for i in range(1,len(lis)):
  # print(lis[i].text)
  fenlei.append(lis[i].text)
print(fenlei)
'''
Exit_fenlei=get_fenleiInfo()
print("已存在的工具分类有{}".format(get_fenleiInfo()))


#####点击“新建分类”按钮
New_fenLeiName='HQ_20191201'
if New_fenLeiName in Exit_fenlei :
    print("该分类已存在,请重新输入分类名或删除已存在的分类")
    #######删除已存在的分类
else:
    driver.find_element_by_xpath("//*[@class='ant-btn newBtn ant-btn-primary']").click()
    #####输入相关信息
    driver.find_element_by_xpath("//*[@id='pluginGroupName']").send_keys(New_fenLeiName)
    driver.find_element_by_xpath("//*[@id='orderNum']").send_keys("1")
    driver.find_element_by_xpath("//*[@id='remark']").send_keys("remarkremark")
    #####输入相关信息_“确认”按钮
    driver.find_element_by_xpath("//*[@class='ant-btn ant-btn-primary']").click()
    #####输入相关信息_“取消”按钮
    # driver.find_element_by_xpath("//*[@class='ant-btn']").click()
    sleep(3)
    #####打印出添加后分类列表数据
    Add_Fenlei=get_fenleiInfo()
    print("添加后，分类有{}".format(Add_Fenlei))
    if New_fenLeiName in Add_Fenlei:
        print("添加新分类{}成功".format(New_fenLeiName))
sleep(2)

driver.quit()












